#!/bin/bash

cp -r $SRC_DIR/python/test .
cd test
python test_spglib.py


